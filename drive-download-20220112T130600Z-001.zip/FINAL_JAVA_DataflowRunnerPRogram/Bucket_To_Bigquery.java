/**
 * GCS Bucket to Bigquery Data transfomation and loading in Apache beam
 *
 * This reads a file given to the program from accessible GCS bucket
 * and loads in the beam pipeline. 
 *	
 * This pipeline 1.cleans each field and row of the file read 
 *				 2. Replaces the original date format with standard date format for BigQuery
 * 
 * To change the input source of the program : Change @TextIO.read()... Path to sotred file
 *
 * <p>To run this java file using managed resource in Google Cloud
 * Platform, specify a command line argument in following format:
 * 			mvn compile exec:java -e -Dexec.mainClass=com.beam.start.Bucket_To_Bigquery \
 *			-Dexec.args="--project=<YOUR_PROJECT_ID> --stagingLocation=gs://<YOUR_BUCKET_NAME>/staging/ \
 *			--tempLocation=gs://<YOUR_BUCKET_NAME>/ --runner=DataflowRunner"
 */
package com.beam.start;

import java.util.Arrays;

import com.google.api.services.bigquery.model.TableFieldSchema;
import com.google.api.services.bigquery.model.TableRow;
import com.google.api.services.bigquery.model.TableSchema;

import org.apache.beam.sdk.Pipeline;
import org.apache.beam.sdk.options.PipelineOptionsFactory;
import org.apache.beam.sdk.transforms.DoFn;
import org.apache.beam.sdk.transforms.ParDo;

import org.apache.beam.sdk.io.TextIO;
import org.apache.beam.sdk.io.gcp.bigquery.BigQueryIO;

public class Bucket_To_Bigquery {

  static class FilterCSVHeaderFn extends DoFn<String, TableRow> {
    //Local variable to hold the input header line so as to filter it out
    String headerFilter;
    
    //Constructor to set the local instance variable of type String with an identity and object.
    public FilterCSVHeaderFn(String headerFilter) {
        this.headerFilter = headerFilter;
        //Now local headerFilter contains data : "state,gender,year,name,number,created_date"
    }

    //Annotation for the method to use for processing elements. A subclass of DoFn must have a method with this annotation.
    @ProcessElement
    //ProcessContext received pCollection or input at program runtime for reading and performing required operations on data 
    public void processElement(ProcessContext c) {
        // Returns the input element to be processed. Using the element, we have cleaned each row for nextline character
        String row = c.element().replace("\n", "").replace("\r", "");

        // Filter out elements that match the header
        // To check if the current operated row is the header or not, we will compare the current row with the one 
        // Sent from caller function which is header row string.
        // If they are unequal that means the row is actually a record.
        if (!row.equals(this.headerFilter)) {
            //Split the record row by comma so that we can access each individual element of the record.
            String[] record = row.split(",");
            String[] date = record[5].split("/");
            record[5] = date[2].toString() + "-" + date[0].toString() + "-" + date[1].toString();
            // Split the given header format by comma for using individual field in the JSON format setting step ahead.
            String headers[] = headerFilter.split(",");

            //As the records are now filtered and cleaned at basic level, they are ready to write and for that we
            // first need them to convert to a BigQuery Writable format.
            // Create a TableRow type object to parse data into 
            // the JSON that is transmitted over HTTP required to write to the BigQuery.

            //First field is the state : using the header input given from caller function, we are using the same to give the 
            // field names per TableRow JSON structure.
            // Clean each field by removing blank spaces, nextline characters and carriage returns if any.
            // "state,gender,year,name,number,created_date"
            TableRow outRow = new TableRow().set(headers[0], record[0].replace("\n", "").replace(" ","")).set(headers[1], record[1])
            //Second field is stating the gender of the user / record line
                    .set(headers[2], Integer.parseInt(record[2].replace("\n", "").replace(" ","")))
            // Third field contains year and we are converting it to integer data type in order to make it available as integer while ingesting to bigquery
                    .set(headers[3], record[3].replace("\n", "").replace(" ",""))
            //  Fourth field is the name of the user / record 
                    .set(headers[4], Integer.parseInt(record[4].replace("\n", "").replace(" ","")))
            //Fifth field is creation date, by default kept in string format.
                    .set(headers[5], record[5].replace("\n", "").replace(" ",""));
            
            // Return the edited pCollection ie. the TableRow ready to write into Bigquery  
            c.output(outRow);
        }
    }
}
  
  public static void main(String[] args) {
    Pipeline p = Pipeline.create(
        PipelineOptionsFactory.fromArgs(args).withValidation().create());
    String header = "state,gender,year,name,number,created_date";
    TableSchema schema = new TableSchema()
        //Describe individual fields in side the setFild method of TableSchema- Give input as an Array 
        // TableFieldSchema is JSON parser for each field we specify - provide the name/ key and value type
                .setFields(Arrays.asList(new TableFieldSchema().setName("state").setType("STRING"), 
                        new TableFieldSchema().setName("gender").setType("STRING"),
                        new TableFieldSchema().setName("year").setType("NUMERIC"),
                        new TableFieldSchema().setName("name").setType("STRING"),
                        new TableFieldSchema().setName("number").setType("NUMERIC"),
                        new TableFieldSchema().setName("created_date").setType("DATE")));
    /*
        Start applying pTransforms on pipeline 
    */

    // First pTransform is basic reasd from Text source : The file is loaded in GCS bucket prior to executing the project
	
    p.apply(TextIO.read().from("gs://java-dataflow-job/proj_files/usa_names.csv"))
	
    //Next, we need to clean the pCollections - in this case , each individual row of CSV separated by \n is each element in
    //pCollection of the pipeline. This ParDo function gives out the output in random order if we use split kind of operation 
    // in the DoFn. Here we are giving output as a TableRow - a format compatible to write into Bigquery table over HTTP
	
        .apply(ParDo.of(new FilterCSVHeaderFn(header)))
		
    //Now, write the returned pTransforms in bigquery to Bigquery with required parameters set in-line for the destination table
	
        .apply(BigQueryIO.writeTableRows().to("names.usa_names")
	//Provide the schema for making bigquery table - can be string or Schema can be also created from JSON metadata of the table to be created or present already
        .withSchema(schema)
		
	// Create disposition either creates the table if not present OR states if table should be already present before writing
        .withCreateDisposition(BigQueryIO.Write.CreateDisposition.CREATE_IF_NEEDED)
	// Write disposition allows to 1) clear the table before writing to it or 2) append to already existing table data without touching old data
        .withWriteDisposition(BigQueryIO.Write.WriteDisposition.WRITE_APPEND));
		
		
    // Runs this Pipeline according to the PipelineOptions for data transfer
	
    p.run().waitUntilFinish();
  }
}
