just run the 'bash run_spark_project.sh'
