import pyspark
from pyspark.sql import SparkSession

spark = SparkSession.builder.master("local[*]").appName('Sentiment_Analysis').getOrCreate()

from pyspark.sql.functions import *
from pyspark.sql.types import *
from pyspark.sql.functions import udf, array

spark.conf.set("spark.sql.debug.maxToStringFields", 1000)

base = '/home/training/sparkcourse/Project/Data/Tweets'
from os import listdir as ld
files = [file for file in ld(base) if file.endswith('.csv')]

#---------------------------------------------------------------------------
# '1377191648_sentiment_nuclear_power.csv'

file1 = files[2]
id = 1
df1 = spark.read.format('csv').options(header='true', inferschema='true') \
.option("delimiter", ",").option("escape", '\\').option("escape", ':')\
.option("multiLine", True).option('escape', "\"").load(base+"/"+file1)

adf1 = df1.select("sentiment", "tweet_text")
def file1_udf_func(val):
     return "neutral" if "neutral" in val.lower() else "negative" if "negative" in val.lower() else "positive"

file1_udf = udf(file1_udf_func, StringType())
df1 = adf1.withColumn("standardized_value", file1_udf('sentiment'))
df1 = df1.withColumn('dataset_id', lit(id))
df1 = df1.select('dataset_id', "tweet_text", "standardized_value")
df1 = df1.withColumnRenamed("tweet_text", "tweet")
df1.write.save('/home/training/organised/file_1.csv',format='csv', header=True)

#----------------------------------------------------------------
#file2 = 

#--------------------------------------------------------------------------------

#'1384367161_claritin_october_twitter_side_effects-1.csv'

file3 = files[4]
id=3
df3 = spark.read.load(base+"/"+file3, format="csv", header=True)
adf3 = df3.select("sentiment", "content")
def file3_udf_func(val):
     return "negative" if val in [1,2] else "positive" if val in [4,5] else "neutral"
file3_udf = udf(file3_udf_func, StringType())
df3 = adf3.withColumn("standardized_value", file3_udf('sentiment'))
df3 = df3.withColumn('dataset_id', lit(id))
df3 = df3.select('dataset_id', "content", "standardized_value")
df3 = df3.withColumnRenamed("content", "tweet")
df3.write.save('/home/training/organised/file_3.csv',format='csv', header=True)

#------------------------------------------------------------
# 'Deflategate-DFE.csv'

file7 = files[6]
id=7
df7 = spark.read.format('csv').options(header='true', inferschema='true').option("delimiter", ",").option("escape", '\\').option("escape", ':').option("multiLine", True).option('escape', "\"").load(base+"/"+file7)
adf7 = df7.select("deflate_sentiment", "text")

def file7_udf_func(val):
     if val == None: return "neutral"
     elif "negative" in val: return "negative"
     elif "positive" in val: return "positive"
     else : return "neutral"

file7_udf = udf(file7_udf_func, StringType())
df7 = adf7.withColumn("standardized_value", file7_udf('deflate_sentiment'))
df7 = df7.withColumn('dataset_id', lit(id))
df7 = df7.select("dataset_id", "text", "standardized_value") # Select desired columns from a Dataframe
df7 = df7.withColumnRenamed("text", "tweet") # Rename column Names
df7.write.save('/home/training/organised/file_7.csv', format='csv', header=True) # write dataframe to a file in CSV Format


#----------------------------------------------------------------------------
# 'progressive-tweet-sentiment.csv'

# file10 = files[-4]
# df10 = spark.read.format('csv').options(header='true', inferschema='true').option("delimiter", ",").option("escape", '\\').option("escape", ':').option("multiLine", True).option('escape', "\"").load(base+"/"+file10)

# ================================================================================================
merged_df = df1.unionByName(df3)
merged_df = merged_df.unionByName(df7)
merged_df.write.save('/home/training/organised/merged_df.csv',format='csv', header=True)

def func_split(val):
    return val.split(' ')

func_split_udf = udf(func_split, StringType())

# merged_df = merged_df.withColumn('splits', func_split_udf('tweet'))


# ===========================================================
dict_path = '/home/training/sparkcourse/Project/Data/AFINN.txt'
# load dictionary
dict_df = spark.read.format("csv").option("delimiter","\\t").load(dict_path)
dict_df = dict_df.withColumnRenamed("_c0","name").withColumnRenamed("_c1","value")

# ========================================

dd = {}
for i in dict_df.collect():
     dd[i['name']] = int(i['value'])


def calc_rating(val, dd):
     x = (str(val)).split(' ')
     #print("----------------",val, x,type(val),"---------------")
     sum=0
     for i in x:
             sum += dd.get(i,0)
     return sum

def frat(val):
    sum = calc_rating(val,dd)
    return sum

frat_udf = udf(frat, StringType())


mm_collect = merged_df.select('tweet').collect()

rat_list = []
for i in mm_collect:
     ll = calc_rating(i, dd)
     rat_list.append(ll)


from pyspark.sql import Row
rat_df = [Row(i) for i in rat_list]
df = spark.createDataFrame(rat_df, ["rating"])

# --------------------------------------------------------------------------


from pyspark.sql.functions import row_number,lit
from pyspark.sql.window import Window
w = Window().orderBy(lit('A'))
df = df.withColumn("row_num", row_number().over(w))
merged_df = merged_df.withColumn("row_num", row_number().over(w))

# combine/ join
final_df = merged_df.join(df, merged_df.row_num == df.row_num)
final_df = final_df.drop('row_num')
final_df  = final_df.withColumnRenamed('rating', 'computedScore')

# ------------------------------------------------------------

#5th task

def standardize_cs(val):
     return "negative" if val in range(-18,-2) else "neutral" if val in range(-2,3) else "positive"

standardize_cs_udf = udf(standardize_cs,StringType())
fdf = final_df.withColumn('computedScoreCategorized', standardize_cs_udf('computedScore'))
final_df = fdf.withColumnRenamed('standardized_value', 'originalSentiment')


#-------------------------------------------------------------------
# 6th task

def bool_standardize(val):
	return val[0] == val[1]

bool_standardize_udf = udf(bool_standardize,BooleanType())
final_df = final_df.withColumn('bool_val', bool_standardize_udf(array('originalSentiment','computedScoreCategorized')))


#--------------- # generate a report and transfer to mysql -----------------

final_df.write.save('/home/training/organised/final_report.csv', format='csv', header=True)
print("******************** DONE! *********************************");


