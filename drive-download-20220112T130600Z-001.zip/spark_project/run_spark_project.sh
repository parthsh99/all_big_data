rm -R /home/training/Desktop/organised

mkdir /home/training/Desktop/organised

mysql -uroot -ptraining < db_creation.sql
spark-submit spark_project_script.py
